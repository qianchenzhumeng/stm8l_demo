1. 将 size.exe 放在COSMIC编译软件的安装目录，例如：C:\Program Files\COSMIC\CXSTM8
2. 用stvd打开你的工程文件，在工程上点右键选settings...
右侧的选项卡选择Linker，将category的下拉框选成output，然后在Generate Map file前打勾；
3.  再将选项卡上选择到Post-Build，在commands输入框中增加一行：size $(OutputPath)$(TargetSName).map
4. 重新编译(选择Rebuild All),即可显示出代码大小(代码大小单位Byte)