1. 将附件压缩包中的mapinfo.exe解压到stvd的\安装路径\STMicroelectronics\st_toolset\stvd中；
2. 用stvd打开你的工程文件，在工程上点右键选settings...
右侧的选项卡选择Linker，将category的下拉框选成output，然后在Generate Map file前打勾；
4. 再将选项卡上选择到Post-Build，在下方文本框中新粘贴一行内容“mapinfo $(OutputPath)$(TargetSName).map”；
5. 点OK按键确定，菜单File->save workspace，保存工程；
6. 重新编译下，你就能看到flash,ram,eeprom占用字节数了 。